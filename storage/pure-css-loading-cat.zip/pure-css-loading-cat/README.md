# Pure CSS Loading Cat

A Pen created on CodePen.io. Original URL: [https://codepen.io/touneko/pen/ygOgWj](https://codepen.io/touneko/pen/ygOgWj).

