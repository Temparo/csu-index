# Night/Day Toggle Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/MarvinRudolph/pen/jemoKZ](https://codepen.io/MarvinRudolph/pen/jemoKZ).

