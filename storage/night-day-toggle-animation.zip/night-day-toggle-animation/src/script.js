const States = {
  NIGHT: 0,
  DAY: 1
};

/**
 * Night Day Toggle Class
 */
class NightDayToggle {
  /**
   * Constructor
   */
  constructor(element) {
    this._element = element;
    this._input = element.querySelector('input[type="checkbox"]');
    this._state = States.NIGHT;
    
    this._initialize();
    this._bindEventListeners();
  }
  
  /**
   * Initializes the toggle
   *
   * @return void
   */
  _initialize() {
    if (this._element.classList.contains('night')) {
        this._state = States.NIGHT;
    } else if (this._element.classList.contains('day')) {
        this._state = States.DAY;
    }
    
    this._setValue();
    this._setBackground();
  }
  
  /**
   * Binds the event listeners
   *
   * @return void
   */
  _bindEventListeners() {
    this._element.addEventListener('change', () => {
      this._toggle();  
    });
  }
  
  /**
   * Toggles the night/day state
   *
   * @return void
   */
  _toggle() {
    if (this._state === States.NIGHT) {
      this._setDay();    
    } else {
      this._setNight();
    }
    
    this._setValue();
    this._setBackground();
  }
  
  /**
   * Sets the state to night
   *
   * @return void
   */
  _setNight() {
    this._element.classList.remove('day');
    this._element.classList.add('night');
    this._state = States.NIGHT;
  }
  
  /**
   * Sets the state to day
   *
   * @return void
   */
  _setDay() {
    this._element.classList.remove('night');
    this._element.classList.add('day');
    this._state = States.DAY;
  }
  
  /**
   * Sets the value of the input
   *
   * @return void
   */
  _setValue() {
    this._input.value = this._state;  
  }
  
  /**
   * Sets the background color to the current state
   */
  _setBackground() {
    let stateName;
    
    if (this._state === States.DAY) {
      stateName = 'day';    
    } else {
      stateName = 'night';   
    }
    
    document.body.style.setProperty('--background', `var(--background-${stateName})`); 
  }
}

document.querySelectorAll('.night-day-toggle').forEach((element) => {
  new NightDayToggle(element);
});